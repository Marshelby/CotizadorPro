import Resultados from './Resultados';

function App() {
  return <Resultados />;
}

export default App;